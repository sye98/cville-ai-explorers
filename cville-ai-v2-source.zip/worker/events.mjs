export const FEED_URL='https://www.meetup.com/cville-tech/events/ical/';
const FRESH_MS=5*60*1000, STALE_MS=24*60*60*1000;
let memory=null, inFlight=null;
const unescapeICS=value=>value.replace(/\\([nN,;\\])/g,(_,c)=>/[nN]/.test(c)?'\n':c);
export function plainText(value){
 return value.replace(/!\[([^\]]*)\]\([^)]*\)/g,'$1').replace(/\[([^\]]+)\]\([^)]*\)/g,'$1').replace(/<[^>]*>/g,'').replace(/^[ \t]*#{1,6}\s+/gm,'').replace(/\*{1,3}|`/g,'').replace(/\\([.,!?_-])/g,'$1').trim();
}
export function calendarDate(value,tz='America/New_York'){
 const m=/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})(Z)?$/.exec(value);
 if(!m)throw new Error('Unsupported event date');
 const [,y,mo,d,h,mi,s,z]=m;const wall=Date.UTC(+y,+mo-1,+d,+h,+mi,+s);
 if(z)return new Date(wall).toISOString();
 const fmt=new Intl.DateTimeFormat('en-US',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
 let instant=wall;
 for(let i=0;i<3;i++){const p=Object.fromEntries(fmt.formatToParts(new Date(instant)).map(x=>[x.type,x.value]));const rendered=Date.UTC(+p.year,+p.month-1,+p.day,+p.hour,+p.minute,+p.second);instant+=wall-rendered;}
 return new Date(instant).toISOString();
}
export function parseCalendar(text){
 if(!text.startsWith('BEGIN:VCALENDAR')||!text.includes('END:VCALENDAR'))throw new Error('Invalid calendar');
 const unfolded=text.replace(/\r?\n[ \t]/g,'');
 const blocks=unfolded.match(/BEGIN:VEVENT\r?\n[\s\S]*?END:VEVENT/g)||[];
 const entries=[];
 for(const block of blocks){
  const props={};
  for(const line of block.split(/\r?\n/)){const colon=line.indexOf(':');if(colon<0)continue;const left=line.slice(0,colon);const key=left.split(';')[0].toUpperCase();props[key]={value:unescapeICS(line.slice(colon+1)),params:left};}
  const title=props.SUMMARY?.value||'';
  // Match the actual event title, not sponsors mentioned in an unrelated event description.
  if(!/cville\s+ai\s+explorers|charlottesville\s+ai\s+explorers|\bCvAIEx\b/i.test(title))continue;
  const href=props.URL?.value||'';
  if(!/^https:\/\/(?:www\.)?meetup\.com\/cville-tech\/events\/[a-z0-9]+\/?$/i.test(href))continue;
  try{
   const tz=/TZID=([^;:]+)/.exec(props.DTSTART.params)?.[1]||'America/New_York';
   const start=calendarDate(props.DTSTART.value,tz);
   const end=props.DTEND?calendarDate(props.DTEND.value,/TZID=([^;:]+)/.exec(props.DTEND.params)?.[1]||tz):new Date(Date.parse(start)+2*3600000).toISOString();
   if(Date.parse(end)<=Date.parse(start))continue;
   const description=props.DESCRIPTION?.value||'';
   const paragraphs=description.replace(/^Charlottesville Technologists\s*\n/i,'').split(/\n\s*\n/).map(x=>x.trim()).filter(Boolean);
   const first=paragraphs[0]||'';
   const topic=/^\*\*([^*]+)\*\*/.exec(first)?.[1]||(/^#{1,3}\s/.test(first)?plainText(first):'');
   const body=plainText((topic?paragraphs.slice(1):paragraphs).join('\n\n')).split(/\n(?:Event Details|Organizers|Sponsors)\b/i)[0].replace(/\n\s*[-*]{3,}\s*/g,'\n\n').trim();
   const firstParagraph=body.split(/\n\s*\n/)[0]||'';
   const summary=firstParagraph.length>285?firstParagraph.slice(0,282).replace(/\s+\S*$/,'')+'…':firstParagraph;
   const location=plainText(props.LOCATION?.value||/^Location:\s*(.+)$/im.exec(description)?.[1]||'See Meetup for the venue');
   entries.push({id:props.UID?.value||href,title,topic:plainText(topic)||title,summary,description:body.slice(0,3500),location,start,end,timeZone:tz,url:href,status:props.STATUS?.value||'CONFIRMED',sequence:Number(props.SEQUENCE?.value||0),modified:props['LAST-MODIFIED']?.value||'',raw:block});
  }catch{continue;}
 }
 const latest=new Map();
 for(const event of entries){const prior=latest.get(event.id);if(!prior||event.sequence>prior.sequence||event.sequence===prior.sequence&&event.modified>=prior.modified)latest.set(event.id,event);}
 return {events:[...latest.values()].sort((a,b)=>Date.parse(a.start)-Date.parse(b.start)),timezone:unfolded.match(/BEGIN:VTIMEZONE\r?\n[\s\S]*?END:VTIMEZONE/g)?.join('\r\n')||''};
}
export function chooseNext(events,now=Date.now()){return events.find(e=>e.status.toUpperCase()!=='CANCELLED'&&Date.parse(e.end)>now)||null;}
async function readFeed(request,fetcher,cache){
 const now=Date.now();let previous=memory;
 const key=new Request(new URL('/__meetup-feed-cache-v2',request.url));
 if(!previous&&cache){try{const saved=await cache.match(key);if(saved)previous=await saved.json();}catch{}}
 if(previous&&now-Date.parse(previous.checkedAt)<FRESH_MS){memory=previous;return {...previous,stale:false};}
 try{
  if(!inFlight)inFlight=(async()=>{
   const response=await fetcher(FEED_URL,{headers:{Accept:'text/calendar'},signal:AbortSignal.timeout(8000)});
   if(!response.ok)throw new Error('Meetup unavailable');
   const text=await response.text();if(text.length>1024*1024)throw new Error('Calendar too large');
   const parsed=parseCalendar(text);const fresh={...parsed,checkedAt:new Date().toISOString()};memory=fresh;
   if(cache){try{await cache.put(key,new Response(JSON.stringify(fresh),{headers:{'Content-Type':'application/json','Cache-Control':'public, max-age=86400'}}));}catch{}}
   return fresh;
  })().finally(()=>{inFlight=null;});
  return {...await inFlight,stale:false};
 }catch(error){if(previous&&now-Date.parse(previous.checkedAt)<STALE_MS)return {...previous,stale:true};throw error;}
}
export async function handleEvents(request,options={}){
 const route=new URL(request.url).pathname;
 if(!['/api/events','/api/calendar'].includes(route))return new Response('Not found',{status:404});
 if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405,headers:{Allow:'GET, HEAD'}});
 const json=(value,status=200)=>new Response(request.method==='HEAD'?null:JSON.stringify(value),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
 try{
  const cache=options.cache??(typeof caches!=='undefined'?caches.default:undefined);
  const result=await readFeed(request,options.fetcher||fetch,cache);
  const next=chooseNext(result.events);
  if(route==='/api/calendar'){
   if(!next||result.stale)return new Response('Please check the latest event on Meetup.',{status:503,headers:{'Cache-Control':'no-store'}});
   const calendar=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Cville AI Explorers Concept//EN','CALSCALE:GREGORIAN',result.timezone,next.raw,'END:VCALENDAR',''].filter(Boolean).join('\r\n').replace(/\r?\n/g,'\r\n');
   return new Response(request.method==='HEAD'?null:calendar,{headers:{'Content-Type':'text/calendar; charset=utf-8','Content-Disposition':'attachment; filename="cville-ai-next.ics"','Cache-Control':'no-store'}});
  }
  let event=null;if(next){const {raw,sequence,modified,...publicEvent}=next;event=publicEvent;}
  return json({event,checkedAt:result.checkedAt,stale:result.stale,sourceUrl:FEED_URL});
 }catch{return json({event:null,error:'meetup_unavailable',sourceUrl:FEED_URL},503);}
}
export function resetFeedCache(){memory=null;inFlight=null;}
