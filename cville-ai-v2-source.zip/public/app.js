'use strict';
(() => {
 const $=id=>document.getElementById(id);
 let refreshing=false, lastData=null;
 const groupUrl='https://www.meetup.com/cville-tech/';
 const timeFormat=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',hour:'numeric',minute:'2-digit',timeZoneName:'short'});
 function link(label,url){$('rsvp').replaceChildren(document.createTextNode(label+' '));const arrow=document.createElement('span');arrow.setAttribute('aria-hidden','true');arrow.textContent='↗';$('rsvp').append(arrow);$('rsvp').href=url;}
 function reset(){for(const id of ['event-facts','event-details','calendar'])$(id).hidden=true;$('event-month').textContent='NEXT';$('event-day').textContent='↗';$('event-weekday').textContent='IN CHARLOTTESVILLE';$('event-series').textContent='CVILLE AI EXPLORERS';link('Open Meetup',groupUrl);}
 function render(data){
  reset();$('retry').hidden=!data.stale;const e=data.event;
  const checked=new Date(data.checkedAt);
  $('sync-status').textContent=(data.stale?'Last update ':'Updated ')+timeFormat.format(checked)+' · Meetup';
  $('sync-status').dataset.state=data.stale?'stale':'fresh';
  if(!e||Date.parse(e.end)<=Date.now()){
   $('event-title').textContent='The next date is on its way.';$('event-summary').textContent=data.stale?'We couldn’t refresh the calendar. Check Meetup for the latest announcement.':'No upcoming Cville AI Explorers meetup is listed yet. Follow the group on Meetup for the next announcement.';return;
  }
  const start=new Date(e.start), end=new Date(e.end), tz=e.timeZone||'America/New_York';
  const datePart=options=>new Intl.DateTimeFormat('en-US',{timeZone:tz,...options}).format(start);
  $('event-month').textContent=datePart({month:'short'}).toUpperCase();$('event-day').textContent=datePart({day:'numeric'});$('event-weekday').textContent=datePart({weekday:'long'})+' / '+datePart({year:'numeric'});
  $('event-series').textContent=e.title.replace(/Cville AI Explorers\s*\(CvAIEx\)\s*[-–—]?\s*/i,'').toUpperCase();
  const headline=e.topic.split(/:\s+/)[0];
  $('event-title').textContent=headline.length>=10?headline:e.topic;
  const summary=e.summary.split(/(?<=[.!?])\s+/).slice(0,2).join(' ');
  $('event-summary').textContent=data.stale?'Meetup is temporarily unavailable. These are the last synced details; check Meetup before making plans.':summary;
  const times=new Intl.DateTimeFormat('en-US',{timeZone:tz,hour:'numeric',minute:'2-digit'});
  const zone=new Intl.DateTimeFormat('en-US',{timeZone:tz,timeZoneName:'short'}).formatToParts(start).find(p=>p.type==='timeZoneName')?.value||tz;
  $('event-time').dateTime=e.start;$('event-time').textContent=times.format(start)+' – '+times.format(end)+' '+zone;
  $('event-location').textContent=e.location;$('event-facts').hidden=false;
  const detail=e.description.startsWith(summary)?e.description.slice(summary.length).trim():e.description;
  $('event-description').textContent=detail;$('event-details').hidden=!detail;$('calendar').hidden=data.stale;
  link(data.stale?'Check on Meetup':'RSVP on Meetup',e.url);
 }
 async function refresh(){
  if(refreshing)return;refreshing=true;$('retry').disabled=true;
  try{const response=await fetch('/api/events',{cache:'no-store',signal:AbortSignal.timeout(12000)});if(!response.ok)throw new Error('unavailable');const data=await response.json();lastData=data;render(data);}
  catch{
   if(lastData){render({...lastData,stale:true});}
   else{reset();$('event-title').textContent='Find the next meetup.';$('event-summary').textContent='We couldn’t load the latest event right now. Dates, details, and registration are available on Meetup.';$('sync-status').textContent='Meetup update unavailable';$('sync-status').dataset.state='error';$('retry').hidden=false;}
  }finally{refreshing=false;$('retry').disabled=false;$('event-content').setAttribute('aria-busy','false');}
 }
 $('retry').addEventListener('click',refresh);refresh();
 setInterval(()=>{if(!document.hidden)refresh();},5*60*1000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
 document.querySelectorAll('.card-toggle').forEach(button=>button.addEventListener('click',()=>{const open=button.getAttribute('aria-expanded')==='true';button.setAttribute('aria-expanded',String(!open));$(button.getAttribute('aria-controls')).hidden=open;button.querySelector('span').textContent=open?'Inside this meetup':'Close details';}));
 const dialog=$('share-dialog'),shareUrl='https://cville-ai-focus.sifanye-ghost.chatgpt.site';
 $('share-url').href=shareUrl;$('share-url').textContent=shareUrl.replace('https://','');
 $('share').addEventListener('click',()=>{$('copy-status').textContent='';dialog.showModal();});
 dialog.querySelector('.close').addEventListener('click',()=>dialog.close());
 dialog.addEventListener('click',event=>{if(event.target!==dialog)return;const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();});
 $('copy').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(shareUrl);$('copy-status').textContent='Link copied.';}catch{$('copy-status').textContent='Select the link above to copy it.';}});
})();
