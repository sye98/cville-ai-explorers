# Cville AI Explorers — V2 / Focus

An independent design concept for the Charlottesville AI community.

- **V2:** https://cville-ai-focus.sifanye-ghost.chatgpt.site
- **V1, preserved:** https://cville-ai-woven.sifanye-ghost.chatgpt.site

The visitor journey is intentionally short: curiosity → next event and RSVP → past meetup cards. The textile-inspired hero connects the design to the Ix neighborhood. Newcomer reassurance sits beside RSVP. Community background and repeated invitations no longer interrupt the main journey.

## Live Meetup data

The Worker reads the public group calendar at https://www.meetup.com/cville-tech/events/ical/ and filters **event titles** for Cville AI Explorers / CvAIEx. Other Cville Tech events are excluded, even when they mention the AI group as a sponsor.

The next non-cancelled, non-ended matching event provides the title, description, date, time, venue, RSVP URL and downloadable calendar. Where the feed omits LOCATION, the venue is read from its description; no venue is assumed. Eastern daylight-saving time is handled with Intl. A short cache limits upstream calls to roughly once every five minutes per edge location. The page refreshes every five minutes while visible, and when revisited. This is automatically refreshed calendar data, not an instantaneous push subscription.

On upstream failure, a cached result up to 24 hours old is explicitly labeled with its last update, and calendar downloads are disabled. Without a usable cache, the site shows an unavailable state and links to Meetup. An empty calendar has its own state. Past cards are a curated, source-linked archive, not a live archive feed.

No accounts, visitor database, Meetup credentials, paid API, or analytics are required. All signups happen on Meetup. The application only fetches a fixed public feed URL; it is not an open proxy. External text is rendered as text, never as HTML.

## Run and build

Node.js 22+; no dependencies.

```sh
node serve.mjs
node --test tests/*.test.mjs
node scripts/build.mjs
```

Preview: http://127.0.0.1:4174. The build emits a Cloudflare-compatible ESM Worker at `dist/server/index.js`, bundling the static assets alongside the calendar endpoint. Sites hosts this version separately from V1. The two sites have different project IDs; publishing V2 cannot overwrite V1.

## Sources and attribution

- Original community: https://www.cvaiex.org/
- Meetup calendar: https://www.meetup.com/cville-tech/events/ical/
- September 2026: https://www.meetup.com/cville-tech/events/316395613/
- August 2026: https://www.meetup.com/cville-tech/events/316018645/
- July 2026: https://www.meetup.com/cville-tech/events/315584929/
- June 2026: https://www.meetup.com/cville-tech/events/315069497/
- Ix textile history: https://www.ixartpark.org/about-us
- Meetup calendar documentation: https://help.meetup.com/hc/en-us/articles/39237118960013-Exporting-an-event-to-your-calendar

Archive copy was checked September 27, 2026. The filament artwork was generated for V1 with OpenAI image generation and reused here. It is abstract artwork, not a photograph of the venue. Fonts: DM Sans and Space Grotesk from Google Fonts, with system fallbacks. Community names and factual references belong to their respective owners; this concept is not an official endorsement.
