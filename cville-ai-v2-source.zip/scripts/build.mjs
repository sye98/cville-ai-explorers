import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import path from 'node:path';
const assets={};
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.webp':'image/webp'};
async function collect(dir){for(const item of await readdir(dir,{withFileTypes:true})){const name=path.join(dir,item.name);if(item.isDirectory())await collect(name);else{const route='/'+path.relative('public',name).split(path.sep).join('/');assets[route]={body:(await readFile(name)).toString('base64'),type:types[path.extname(name)]||'application/octet-stream'};}}}
await collect('public');
const events=(await readFile('worker/events.mjs','utf8')).replace(/^export /gm,'');
const worker=events+'\nconst assets='+JSON.stringify(assets)+';\n'+`export default {async fetch(request,env,ctx){
 const url=new URL(request.url);
 if(url.pathname.startsWith('/api/'))return handleEvents(request);
 if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405,headers:{Allow:'GET, HEAD'}});
 const asset=assets[url.pathname==='/'?'/index.html':url.pathname];
 if(!asset)return new Response('Not found',{status:404});
 const body=request.method==='HEAD'?null:Uint8Array.from(atob(asset.body),c=>c.charCodeAt(0));
 return new Response(body,{headers:{'Content-Type':asset.type,'Cache-Control':url.pathname.startsWith('/assets/')?'public, max-age=3600':'public, max-age=60','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin'}});
}};`;
await mkdir('dist/server',{recursive:true});await mkdir('dist/.openai',{recursive:true});
await writeFile('dist/server/index.js',worker);await writeFile('dist/.openai/hosting.json',await readFile('.openai/hosting.json'));
console.log('Worker built with '+Object.keys(assets).length+' bundled assets.');
