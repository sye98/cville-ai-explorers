import http from 'node:http';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
const root=path.resolve('public');
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.webp':'image/webp','.svg':'image/svg+xml'};
http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://127.0.0.1:4174');
  if(url.pathname.startsWith('/api/')){
   const {handleEvents}=await import('./worker/events.mjs');
   const response=await handleEvents(new Request(url));
   res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));return;
  }
  let route=decodeURIComponent(url.pathname);if(route.endsWith('/'))route+='index.html';
  const filename=path.resolve(root,'.'+route);if(!filename.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
  const body=await readFile(filename);res.writeHead(200,{'Content-Type':types[path.extname(filename)]||'application/octet-stream','Cache-Control':'no-cache'});res.end(body);
 }catch{res.writeHead(404);res.end('Not found');}
}).listen(4174,'127.0.0.1',()=>console.log('Local: http://127.0.0.1:4174'));
