import test from 'node:test';
import assert from 'node:assert/strict';
import {parseCalendar,calendarDate,chooseNext,handleEvents,resetFeedCache} from '../worker/events.mjs';
const entry=(extra='')=>`BEGIN:VEVENT\nUID:ai-1\nSUMMARY:Cville AI Explorers (CvAIEx) - Meeting #17\nDTSTART;TZID=America/New_York:20800929T180000\nDTEND;TZID=America/New_York:20800929T200000\nDESCRIPTION:Charlottesville Technologists\\n**AI Design Bake-Off**\\n\\nBuild with AI\\, together.\\n\\n## Event Details\\nLocation: Studio IX\\, Charlottesville\nURL:https://www.meetup.com/cville-tech/events/316395613/\n${extra}END:VEVENT`;
const calendar=content=>`BEGIN:VCALENDAR\nVERSION:2.0\n${content}\nEND:VCALENDAR`;
test('calendar parsing unfolds lines, decodes text, and reads current description and venue',()=>{
 const data=parseCalendar(calendar(entry().replace('Build with AI','Build with\n AI')));
 assert.equal(data.events.length,1);assert.equal(data.events[0].topic,'AI Design Bake-Off');assert.equal(data.events[0].summary,'Build withAI, together.');assert.equal(data.events[0].location,'Studio IX, Charlottesville');
});
test('Eastern dates correctly distinguish summer, winter, and explicit UTC',()=>{
 assert.equal(calendarDate('20260929T180000'),'2026-09-29T22:00:00.000Z');assert.equal(calendarDate('20260129T180000'),'2026-01-29T23:00:00.000Z');assert.equal(calendarDate('20260929T220000Z'),'2026-09-29T22:00:00.000Z');
});
test('ignores unrelated meetups even if Cville AI Explorers appears in sponsor text',()=>{
 const other=entry().replace('Cville AI Explorers (CvAIEx) - Meeting #17','beCamp').replace('Build with AI','Cville AI Explorers');assert.equal(parseCalendar(calendar(other)).events.length,0);
});
test('newer cancellation wins and ended events are never shown as next',()=>{
 const list=parseCalendar(calendar(entry('SEQUENCE:1\n')+'\n'+entry('SEQUENCE:2\nSTATUS:CANCELLED\n'))).events;
 assert.equal(chooseNext(list,0),null);assert.equal(chooseNext(parseCalendar(calendar(entry())).events,Date.parse('2081-01-01')),null);
});
test('rejects non-Meetup URLs and malformed dates',()=>{
 assert.equal(parseCalendar(calendar(entry().replace('https://www.meetup.com/cville-tech/events/316395613/','javascript:alert(1)'))).events.length,0);
 assert.equal(parseCalendar(calendar(entry().replace('20800929T180000','not-a-date'))).events.length,0);
 assert.throws(()=>parseCalendar('<html>Access denied</html>'));
});
test('API distinguishes fresh, empty and unavailable feeds; calendar follows live event',async()=>{
 resetFeedCache();const req=new Request('https://example.test/api/events');let count=0;
 const fetcher=async()=>{count++;return new Response(calendar(entry()));};
 const fresh=await (await handleEvents(req,{fetcher})).json();assert.equal(fresh.stale,false);assert.equal(fresh.event.topic,'AI Design Bake-Off');assert.ok(!('raw' in fresh.event));
 const ics=await handleEvents(new Request('https://example.test/api/calendar'),{fetcher});assert.equal(ics.status,200);assert.match(await ics.text(),/BEGIN:VEVENT/);assert.equal(count,1);
 resetFeedCache();const empty=await (await handleEvents(req,{fetcher:async()=>new Response(calendar(''))})).json();assert.equal(empty.event,null);assert.equal(empty.stale,false);
 resetFeedCache();const failed=await handleEvents(req,{fetcher:async()=>new Response('Unavailable',{status:503})});assert.equal(failed.status,503);assert.equal((await failed.json()).error,'meetup_unavailable');
});
test('failed refresh is labeled stale and cannot download an outdated calendar',async()=>{
 resetFeedCache();const req=new Request('https://example.test/api/events');await handleEvents(req,{fetcher:async()=>new Response(calendar(entry()))});
 const realNow=Date.now;const later=realNow()+6*60*1000;Date.now=()=>later;
 try{
  const fetcher=async()=>{throw new Error('offline');};const stale=await (await handleEvents(req,{fetcher})).json();assert.equal(stale.stale,true);assert.ok(stale.event);
  assert.equal((await handleEvents(new Request('https://example.test/api/calendar'),{fetcher})).status,503);
 }finally{Date.now=realNow;resetFeedCache();}
});
